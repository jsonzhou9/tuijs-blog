var Load = {
	imgs:{}, //已加载的资源列表
	loadImgLen:0, //已加载的图片个数(包括失败)
	imgErrLen:0, //加载出错的个数
	imgLen:0, //总共需加载的图片个数
	loadImgState:{ //状态枚举
		"0":"图片未加载",
		"1":"图片加载成功",
		"2":"图片加载失败，资源错误",
		"3":"图片加载失败，已存在相同的图片ID"
	},
	loadImage:function(_opation){
		this.showLoadIcon = _opation.showLoadIcon || false;
		var _list = _opation.list,
			onload = _opation.onload,
			onprogress = _opation.onprogress,
			onerror = _opation.onerror,
			oncomplete = _opation.oncomplete;
		var eventList = {onload:onload,onprogress:onprogress,onerror:onerror,oncomplete:oncomplete};
		
		if(_list.length>0){
			this.imgLen = _list.length;
			this.loadImgLen = 0;
			this.imgErrLen = 0;
			
			if(this.showLoadIcon){ //显示loading图标
				this.loadIcon();
			}
		
			for(var i=0;i<_list.length;i++){
				var img = this.getImageObj();
        		img.src = _list[i].src;
				img.picname = _list[i].id;
				img.onload = this.imgOnload.bind(img,eventList);
				img.onerror = this.imgOnErr.bind(img,eventList);
			}
		}
	},
	imgOnload:function(eventList){
		Load.loadImgLen++;
		var state = 0;
		if(typeof Load.imgs[this.picname] == "undefined"){
			Load.imgs[this.picname] = this;
			Load.imageCallBack(eventList.onload,{src:this.src,id:this.picname,state:1,msg:Load.loadImgState[1]});
			state = 1;
		}else{
			Load.imgErrLen++;
			Load.imageCallBack(eventList.onerror,{src:this.src,id:this.picname,state:3,msg:Load.loadImgState[3]});
			state = 3;
		}
		Load.imgOnProgress(this,eventList,state);
	},
	imgOnProgress:function(imgObj,eventList,state){
		if(Load.showLoadIcon){
			Load.loadText = Math.round(Load.loadImgLen/Load.imgLen*100)+"%";
		}
		Load.imageCallBack(eventList.onprogress,{src:imgObj.src,id:imgObj.picname,imgLen:Load.imgLen,loadImgLen:Load.loadImgLen,imgErrLen:Load.imgErrLen,state:state,msg:Load.loadImgState[state]});
		if(Load.loadImgLen==Load.imgLen){ //加载完成
			Load.imageCallBack(eventList.oncomplete,{imgLen:Load.imgLen,imgErrLen:Load.imgErrLen});
			if(Load.showLoadIcon){
				Load.stopLoadIcon();
			}
		}
	},
	imgOnErr:function(eventList){ //图片加载时触发
		Load.loadImgLen++;
		Load.imgErrLen++;
		Load.imageCallBack(eventList.onerror,{src:this.src,id:this.picname,state:2,msg:Load.loadImgState[2]});
		Load.imgOnProgress(this,eventList,2);
	},
	imageCallBack:function(_cb){ //回调总控方法
		if (typeof _cb == "function") {
			var args = Array.prototype.slice.call(arguments,1);
        	_cb.apply(_cb,args);
        }
	},
	getImage: function(_name) {
		if (this.imgs[_name]) {
			return this.imgs[_name]
		}
	},
	delImage: function(_name) {
		if (this.imgs[_name]) {
			this.imgs[_name] = null;
			delete this.imgs[_name];
		}
	},
	getImageObj: function() {
    	return new Image();
    },
    //loading icon start
    loadIconTimer:null,
	canvasObj:null,
    loadContext:null,
	loadPoint:[],
	loadPos:0, //当前点亮
	loadText:"0%",
	setLoadIcon: function(_opation){ //设置进度条
        this.canvasObj = document.getElementById(_opation.id);
        this.loadWidth = _opation.width || 60;
        this.loadHeight = _opation.height || 60;
		this.circleR = _opation.circleR || 4;
		this.circleCount = _opation.circleCount || 10;
        this.showLoadText = _opation.showLoadText || true;
        this.loadTextSize = _opation.loadTextSize || 16;
		this.loadTextColor = _opation.loadTextColor || "#000000"; //百分比文字的颜色
		this.loadTextAlpha = _opation.loadTextAlpha || 0.6; //百分比文字颜色的透明度
        this.loadColor = _opation.loadColor || "#000000"; //背景圆的颜色
		this.loadAlpha = _opation.loadAlpha || 0.1; //背景圆的颜色的透明度
		this.focusColor = _opation.focusColor || "#000000"; //高亮焦点颜色
	},
    loadIcon:function(){
        var that = this;
        if(this.canvasObj){
            this.canvasObj.style.visibility = "visible";
            this.canvasObj.width = this.loadWidth;
            this.canvasObj.height = this.loadHeight;
            this.getLoadPoint(this.loadWidth/2-this.circleR,this.loadWidth/2,this.loadHeight/2,this.circleCount);
            this.loadContext = this.canvasObj.getContext("2d");
            //画圆
            this.drawCircle();
            //点亮圆
            this.loadIconTimer = setInterval(function(){
                if(that.loadPos>that.circleCount-1)that.loadPos=0;
                that.clearCanvas();
                that.drawText();
                that.drawCircle();
                that.drawFocus(that.loadPos);
                that.loadPos++;
            },60);
        }
    },
	getLoadPoint: function(r,ox,oy,count){ //求圆周上等分点的坐标
		var radians = (Math.PI / 180) * Math.round(360 / count); //弧度
		for(var i = 0; i < count; i++){
			var x = ox + r * Math.sin(radians * i); //ox,oy为圆心坐标
			var y = oy + r * Math.cos(radians * i);
			this.loadPoint.unshift({x:x,y:y});
		}
	},
	drawFocus: function(startPos){
		var count = this.circleCount/2; //亮点圆个数
		var k = 0;
		while(k<count){
			if(startPos>this.circleCount-1)startPos=0;
			var alpha = (1/(this.circleCount/2))*k;
			this.drawRound(this.loadPoint[startPos].x,this.loadPoint[startPos].y,this.circleR,this.focusColor,alpha);
			startPos++;
			k++;
		}
	},
	drawCircle:function(){//画背景圆
		for(var i=0;i<this.loadPoint.length;i++){
            this.drawRound(this.loadPoint[i].x,this.loadPoint[i].y,this.circleR,this.loadColor,this.loadAlpha);
		}
	},
	drawText: function(){ //绘制文字
        if(this.showLoadText){
            var fillStyle = Color2RGB(this.loadTextColor,this.loadTextAlpha);
            var maxWidth = this.loadWidth - this.circleR*4 - 6;
            this.loadContext.save();
            this.loadContext.font = this.loadTextSize+"px 'Century Gothic'";
            this.loadContext.textAlign = "center";
            this.loadContext.textBaseline = "middle";
            this.loadContext.fillStyle = fillStyle;
            this.loadContext.fillText(this.loadText,this.loadWidth/2,this.loadHeight/2,maxWidth);
            this.loadContext.restore();
        }
	},
    drawRound: function(x,y,radius,color,alpha){ //画单个圆
        var fillStyle = Color2RGB(color,alpha);
        this.loadContext.save();
        this.loadContext.beginPath();
        this.loadContext.arc(x,y,radius,0,Math.PI*2,true);
        this.loadContext.fillStyle = fillStyle;
        this.loadContext.fill();
        this.loadContext.closePath();
        this.loadContext.restore();
    },
	clearCanvas: function(){
		this.canvasObj.width = 0;
		this.canvasObj.width = this.loadWidth;
	},
    stopLoadIcon:function(){
		this.canvasObj.style.visibility = "hidden";
		clearInterval(this.loadIconTimer);
    }
}

//公用扩展
function Color2RGB(strhex,alpha){
    var hexStr ="0123456789ABCDEF";
    var strhex = strhex.toUpperCase();
    var r = hexStr.indexOf(strhex.charAt(1))*16 + hexStr.indexOf(strhex.charAt(2));
    var g = hexStr.indexOf(strhex.charAt(3))*16 + hexStr.indexOf(strhex.charAt(4));
    var b = hexStr.indexOf(strhex.charAt(5))*16 + hexStr.indexOf(strhex.charAt(6));
    return "rgba("+r+","+g+","+b+","+alpha+")";
}
Function.prototype.bind = function() {
    var __method = this;
    var args = Array.prototype.slice.call(arguments);//将arguments转换为数组
    var object=args.shift(); //截取第一个
    return function() {
        return __method.apply(object,
        	args.concat(Array.prototype.slice.call(arguments))
        );
    }
}